﻿using System;
using System.Windows;
using System.Windows.Controls;
using QUIBEE_IPLS.Class;

namespace QUIBEE_IPLS
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            string nickname = TxtUser.Text?.Trim();
            string password = TxtPassword.Password;
            string errorMessage = string.Empty;

            int idCustomer = 0;
            string userGrade = string.Empty;

            if (string.IsNullOrWhiteSpace(nickname))
            {
                MessageBox.Show("Ingrese el usuario.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtUser.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Ingrese la contraseña.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtPassword.Focus();
                return;
            }

            try
            {
                CLogin service = new CLogin();

                if (service.LoginUser(nickname, password, out idCustomer, out userGrade, out errorMessage))
                {
                    MessageBox.Show($"¡Inicio de sesión exitoso! Bienvenido, {nickname}.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);

                    Lessons window = new Lessons(idCustomer, nickname, userGrade);
                    window.Show();

                    this.Close();
                }
                else
                {
                    MessageBox.Show(errorMessage, "Error de Inicio de Sesión", MessageBoxButton.OK, MessageBoxImage.Error);
                    TxtPassword.Clear();
                    TxtPassword.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error inesperado: {ex.Message}", "Error del Sistema", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Register window = new Register();
            this.Close();
            window.Show();
        }
    }
}
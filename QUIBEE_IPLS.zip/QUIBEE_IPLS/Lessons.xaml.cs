﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using QUIBEE_IPLS.Class;

namespace QUIBEE_IPLS
{
    public partial class Lessons : Window
    {
        private readonly CLessons _lessonManager;

        private int _currentUserId;
        private string _currentUserNickname;
        private string _currentUserGrade;

        public Lessons(int userId, string nickname, string grade)
        {
            InitializeComponent();
            _lessonManager = new CLessons();

            _currentUserId = userId;
            _currentUserNickname = nickname;
            _currentUserGrade = grade;

            LoadUserData();
            LoadLessons();
        }

        private void LoadUserData()
        {
            TxtUserInfo.Text = $"Usuario: {_currentUserNickname} | Grado: {_currentUserGrade}";
        }

        private void LoadLessons()
        {
            string errorMessage;

            List<CLessons> lessons = _lessonManager.GetLessonsByGrade(_currentUserGrade, _currentUserId, out errorMessage);

            if (lessons.Any() && string.IsNullOrEmpty(errorMessage))
            {
                LessonsListView.ItemsSource = lessons;
            }
            else if (!string.IsNullOrEmpty(errorMessage))
            {
                MessageBox.Show($"No se pudieron cargar las lecciones: {errorMessage}",
                    "Error de Carga", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                MessageBox.Show($"No se encontraron lecciones activas para el grado {_currentUserGrade}.",
                    "Sin Datos", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        public void BtnStartLesson_Click(object sender, RoutedEventArgs e)
        {
            CLessons selectedLesson = LessonsListView.SelectedItem as CLessons;

            if (selectedLesson == null)
            {
                MessageBox.Show("Selecciona una lección para iniciar.",
                    "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!selectedLesson.State)
            {
                MessageBox.Show($"La lección '{selectedLesson.Title}' no está activa.",
                    "Lección Inactiva", MessageBoxButton.OK, MessageBoxImage.Stop);
                return;
            }

            MessageBox.Show($"Iniciando lección: {selectedLesson.Title}\nTu progreso actual: {selectedLesson.TotalScore}%",
                "Iniciar", MessageBoxButton.OK, MessageBoxImage.Information);

        }

        public void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void LessonsListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
        }
    }
}
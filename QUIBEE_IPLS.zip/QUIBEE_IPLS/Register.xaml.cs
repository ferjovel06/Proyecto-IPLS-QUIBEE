﻿using System;
using System.Windows;
using System.Windows.Controls;
using QUIBEE_IPLS.Class;

namespace QUIBEE_IPLS
{
    public partial class Register : Window
    {
        public Register()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            string nickname = TxtNickname.Text?.Trim();
            string password = PwbPassword.Password;
            string grade = (CmbGrade.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
            string gender = (CmbGender.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
            string rol = (CmbRol.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";

            DateTime? birthday = DPBirthday.SelectedDate;

            if (string.IsNullOrWhiteSpace(nickname))
            {
                MessageBox.Show("Ingrese un Nickname válido.", "Error de Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtNickname.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(password) || password.Length < 4)
            {
                MessageBox.Show("Ingrese una contraseña válida (mínimo 4 caracteres).", "Error de Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                PwbPassword.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(grade) || string.IsNullOrWhiteSpace(gender) || string.IsNullOrWhiteSpace(rol))
            {
                MessageBox.Show("Por favor, seleccione su Grado, Género y Rol.", "Error de Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!birthday.HasValue)
            {
                MessageBox.Show("Por favor, seleccione su Fecha de Nacimiento.", "Error de Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                DPBirthday.Focus();
                return;
            }


            CRegister registerManager = new CRegister();

            if (registerManager.RegisterUser(nickname, grade, gender, rol, password, out string errorMessage))
            {
                MessageBox.Show("¡Usuario registrado exitosamente!", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);

                MainWindow mainWindow = new MainWindow();
                this.Close();
                mainWindow.Show();
            }
            else
            {
                MessageBox.Show(errorMessage, "Error de Registro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Se ha cambiado la variable 'Window' a 'mainWindow' para evitar conflictos de nombres y mejorar la claridad.
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
        }

        private void BtnTutorialLink_Click(object sender, RoutedEventArgs e)
        {
            // Lógica para manejar el clic en el enlace de tutorial
            MessageBox.Show("Enlace al tutorial no implementado todavía.");
        }

        private void BtnConfirmar_Click(object sender, RoutedEventArgs e)
        {
            // Lógica para el botón Confirmar (puedes personalizarla)
        }

        private void BtnRegresar_Click(Object sender, RoutedEventArgs e) { 
        
        }
    }
}
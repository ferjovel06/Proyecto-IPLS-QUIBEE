﻿using System;
using System.Windows;
using System.Windows.Controls;
using QUIBEE_IPLS.Class;

namespace QUIBEE_IPLS
{
    public partial class Register : Window
    {
        public Register()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            string nickname = TxtNickname.Text?.Trim();
            string password = PwbPassword.Password;

            string grade = (CmbGrade.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
            string gender = (CmbGender.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
            string rol = (CmbRol.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";

            DateTime? birthday = DPBirthday.SelectedDate;

            if (string.IsNullOrWhiteSpace(nickname))
            {
                MessageBox.Show("Ingrese un Nickname válido.", "Error de Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtNickname.Focus();
                return;
            }

            if (!birthday.HasValue)
            {
                MessageBox.Show("Por favor, seleccione su Fecha de Nacimiento.", "Error de Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                DPBirthday.Focus();
                return;
            }


            CRegister registerManager = new CRegister();

            if (registerManager.RegisterUser(nickname, grade, gender, rol, password, out string errorMessage))
            {
                MessageBox.Show("¡Usuario registrado exitosamente!", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);

                MainWindow mainWindow = new MainWindow();
                this.Close();
                mainWindow.Show();
            }
            else
            {
                MessageBox.Show(errorMessage, "Error de Registro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow Window = new MainWindow();
            this.Close();
            Window.Show();
        }
    }
}
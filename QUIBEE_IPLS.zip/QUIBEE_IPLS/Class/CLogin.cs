﻿using System;
using System.Windows;
using Npgsql;

namespace QUIBEE_IPLS.Class
{
    internal class CLogin
    {
        public bool LoginUser(string nickname, string password, out string errorMessage)
        {
            errorMessage = "";

            if (string.IsNullOrWhiteSpace(nickname) || string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "El nombre de usuario y el pin son campos obligatorios.";
                return false;
            }

            try
            {
                CConect conexion = new CConect();
                using (var conn = conexion.EstablecerConexion())
                {
                    string sql = @"SELECT password FROM customer WHERE nickname = @nickname";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@nickname", nickname);

                        if (!(cmd.ExecuteScalar() is string storedPassword))
                        {
                            errorMessage = "El nombre de usuario o el pin incorrectos.";
                            return false;
                        }

                        if (password == storedPassword)
                        {
                            MessageBox.Show($"¡Inicio de sesión exitoso! Bienvenido, {nickname}.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                            return true;
                        }
                        else
                        {
                            errorMessage = "El nombre de usuario o el pin incorrectos.";
                            return false;
                        }
                    }
                }
            }
            catch (NpgsqlException sqlEx)
            {
                errorMessage = $"Error de Base de Datos: {sqlEx.Message}";
                return false;
            }
            catch (Exception ex)
            {
                errorMessage = "Error al iniciar sesión: " + ex.Message;
                return false;
            }
        }
    }
}

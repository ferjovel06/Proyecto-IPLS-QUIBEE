﻿using System;
using Npgsql;
using System.Data; // Incluimos System.Data por si es necesario para ConnectionState, aunque el using System.Windows; que pusiste no es necesario aquí y lo quitaré para que la clase sea más limpia.

namespace QUIBEE_IPLS.Class
{
    // Clase para manejar las operaciones de inicio de sesión (Login)
    internal class CLogin
    {
        // Método para validar las credenciales de un usuario.
        // Devuelve true si el login es exitoso, y proporciona el ID y Grado del cliente.
        public bool LoginUser(string nickname, string password, out int idCustomer, out string userGrade, out string errorMessage)
        {
            errorMessage = "";
            idCustomer = 0;
            userGrade = "";
            NpgsqlConnection connection = null;

            if (string.IsNullOrWhiteSpace(nickname) || string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "El nombre de usuario y la contraseña son obligatorios.";
                return false;
            }

            try
            {
                CConect conexion = new CConect();
                connection = conexion.EstablecerConexion();

                if (connection == null)
                {
                    errorMessage = "Error de conexión a la base de datos.";
                    return false;
                }

                // Consulta que busca el nickname y recupera la contraseña, ID y Grado.
                string sql = @"
                    SELECT 
                        id_customer, 
                        password, 
                        grade, 
                        nickname 
                    FROM customer 
                    WHERE 
                        nickname = @nickname";

                using (var cmd = new NpgsqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@nickname", nickname);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string storedPassword = reader.GetString(reader.GetOrdinal("password"));

                            // *** VALIDACIÓN CRUCIAL ***
                            if (password == storedPassword)
                            {
                                idCustomer = reader.GetInt32(reader.GetOrdinal("id_customer"));
                                userGrade = reader.GetString(reader.GetOrdinal("grade"));
                                return true; // Login exitoso
                            }
                            else
                            {
                                errorMessage = "Contraseña incorrecta.";
                                return false;
                            }
                        }
                        else
                        {
                            errorMessage = "El usuario no existe.";
                            return false;
                        }
                    }
                }
            }
            catch (NpgsqlException sqlEx)
            {
                errorMessage = $"Error de Base de Datos al intentar iniciar sesión: {sqlEx.Message}";
                // No muestres MessageBox.Show aquí, deja que la capa de presentación lo maneje
                return false;
            }
            catch (Exception ex)
            {
                errorMessage = "Error general al iniciar sesión: " + ex.Message;
                return false;
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
    }
}
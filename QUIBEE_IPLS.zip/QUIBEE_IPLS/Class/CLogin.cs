﻿using System;
using Npgsql;
using System.Data; 

namespace QUIBEE_IPLS.Class
{
    internal class CLogin
    {
        public bool LoginUser(string nickname, string password, out int idCustomer, out string userGrade, out string errorMessage)
        {
            errorMessage = "";
            idCustomer = 0;
            userGrade = "";
            NpgsqlConnection connection = null;

            if (string.IsNullOrWhiteSpace(nickname) || string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "El nombre de usuario y la contraseña son obligatorios.";
                return false;
            }

            try
            {
                CConect conexion = new CConect();
                connection = conexion.EstablecerConexion();

                if (connection == null)
                {
                    errorMessage = "Error de conexión a la base de datos.";
                    return false;
                }

                string sql = @"
                    SELECT 
                        id_customer, 
                        password, 
                        grade, 
                        nickname 
                    FROM customer 
                    WHERE 
                        nickname = @nickname";

                using (var cmd = new NpgsqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@nickname", nickname);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string storedPassword = reader.GetString(reader.GetOrdinal("password"));

                            if (password == storedPassword)
                            {
                                idCustomer = reader.GetInt32(reader.GetOrdinal("id_customer"));
                                userGrade = reader.GetString(reader.GetOrdinal("grade"));
                                return true; 
                            }
                            else
                            {
                                errorMessage = "Contraseña incorrecta.";
                                return false;
                            }
                        }
                        else
                        {
                            errorMessage = "El usuario no existe.";
                            return false;
                        }
                    }
                }
            }
            catch (NpgsqlException sqlEx)
            {
                errorMessage = $"Error de Base de Datos al intentar iniciar sesión: {sqlEx.Message}";
                return false;
            }
            catch (Exception ex)
            {
                errorMessage = "Error general al iniciar sesión: " + ex.Message;
                return false;
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
    }
}
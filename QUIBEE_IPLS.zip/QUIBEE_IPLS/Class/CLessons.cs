﻿using System;
using System.Collections.Generic;
using Npgsql;
using System.Data;

namespace QUIBEE_IPLS.Class
{
    public class CLessons
    {
        public int IdLesson { get; set; }
        public int IdTopic { get; set; }
        public string Title { get; set; }
        public int Grade { get; set; }
        public bool State { get; set; }
        public string TopicName { get; set; }
        public double TotalScore { get; set; }

        private readonly CConect _db;

        public CLessons()
        {
            _db = new CConect();
        }

        public CLessons(int idLesson, int idTopic, string title, int grade, bool state, string topicName, double total_score)
        {
            IdLesson = idLesson;
            IdTopic = idTopic;
            Title = title;
            Grade = grade;
            State = state;
            TopicName = topicName;
            TotalScore = total_score;
            _db = new CConect();
        }

        public List<CLessons> GetLessonsByGrade(string targetGradeText, int customerId, out string errorMessage)
        {
            errorMessage = string.Empty;
            List<CLessons> lessons = new List<CLessons>();

            int gradeNumber = ExtraerNumeroDeGrado(targetGradeText);

            NpgsqlConnection connection = null;

            try
            {
                connection = _db.EstablecerConexion();
                if (connection == null)
                {
                    errorMessage = "No se pudo conectar a la base de datos.";
                    return lessons;
                }

                string sql = @"
                    SELECT 
                        l.id_lesson, 
                        l.id_topic, 
                        l.title, 
                        l.grade, 
                        l.state,
                        t.topic_name,
                        COALESCE(p.total_score, 0) as total_score
                    FROM lesson l
                    JOIN topic t ON l.id_topic = t.id_topic
                    LEFT JOIN progress p ON l.id_lesson = p.id_lesson AND p.id_customer = @customerId
                    WHERE l.grade = @grade AND l.state = TRUE
                    ORDER BY l.id_lesson";

                using (var cmd = new NpgsqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@grade", gradeNumber.ToString());
                    cmd.Parameters.AddWithValue("@customerId", customerId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string gradeStr = reader.GetValue(reader.GetOrdinal("grade")).ToString();
                            int gradeInt = int.Parse(gradeStr);

                            lessons.Add(new CLessons(
                                idLesson: reader.GetInt32(reader.GetOrdinal("id_lesson")),
                                idTopic: reader.GetInt32(reader.GetOrdinal("id_topic")),
                                title: reader.GetString(reader.GetOrdinal("title")),
                                grade: gradeInt,
                                state: reader.GetBoolean(reader.GetOrdinal("state")),
                                topicName: reader.GetString(reader.GetOrdinal("topic_name")),
                                total_score: Convert.ToDouble(reader.GetValue(reader.GetOrdinal("total_score")))
                            ));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = "Error al obtener las lecciones: " + ex.Message;
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                    connection.Close();
            }

            return lessons;
        }

        private int ExtraerNumeroDeGrado(string gradoTexto)
        {
            if (string.IsNullOrWhiteSpace(gradoTexto)) return 0;

            foreach (char c in gradoTexto)
            {
                if (char.IsDigit(c))
                    return int.Parse(c.ToString());
            }

            return 0;
        }
    }
}
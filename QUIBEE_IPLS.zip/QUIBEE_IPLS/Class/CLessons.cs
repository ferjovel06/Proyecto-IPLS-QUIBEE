﻿using System;
using System.Collections.Generic;
using Npgsql;
using System.Data;
using System.Text.RegularExpressions;

namespace QUIBEE_IPLS.Class
{
    public class CLessons
    {
        public int IdLesson { get; set; }
        public int IdTopic { get; set; }
        public string Title { get; set; }
        public int Grade { get; set; }
        public bool State { get; set; }

        private readonly CConect _db;

        public CLessons()
        {
            _db = new CConect();
        }

        public CLessons(int idLesson, int idTopic, string title, int grade, bool state)
        {
            IdLesson = idLesson;
            IdTopic = idTopic;
            Title = title;
            Grade = grade;
            State = state;
            _db = new CConect();
        }

        public List<CLessons> GetLessonsByGrade(string targetGradeText, out string errorMessage)
        {
            errorMessage = string.Empty;
            List<CLessons> lessons = new List<CLessons>();

            int gradeNumber = ExtraerNumeroDeGrado(targetGradeText);

            NpgsqlConnection connection = null;

            try
            {
                connection = _db.EstablecerConexion();
                if (connection == null)
                {
                    errorMessage = "No se pudo conectar a la base de datos.";
                    return lessons;
                }

                string sql = @"SELECT id_lesson, id_topic, title, grade, state
                               FROM lesson
                               WHERE grade = @grade AND state = TRUE";

                using (var cmd = new NpgsqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@grade", gradeNumber);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lessons.Add(new CLessons(
                                idLesson: reader.GetInt32(reader.GetOrdinal("id_lesson")),
                                idTopic: reader.GetInt32(reader.GetOrdinal("id_topic")),
                                title: reader.GetString(reader.GetOrdinal("title")),
                                grade: reader.GetInt32(reader.GetOrdinal("grade")),
                                state: reader.GetBoolean(reader.GetOrdinal("state"))
                            ));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = "Error al obtener las lecciones: " + ex.Message;
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                    connection.Close();
            }

            return lessons;
        }

        private int ExtraerNumeroDeGrado(string gradoTexto)
        {
            if (string.IsNullOrWhiteSpace(gradoTexto))
                return 0;

            foreach (char c in gradoTexto)
            {
                if (char.IsDigit(c))
                    return int.Parse(c.ToString());
            }

            return 0;
        }

    }
}
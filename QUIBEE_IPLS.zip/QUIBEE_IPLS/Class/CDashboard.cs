using System;
using System.Collections.Generic;
using Npgsql;
using System.Data;

namespace QUIBEE_IPLS.Class
{
    public class CLessons
    {
        // Propiedades existentes
        public int IdLesson { get; set; }
        public int IdTopic { get; set; }
        public string Title { get; set; }
        public int Grade { get; set; }
        public bool State { get; set; }

        // --- NUEVAS PROPIEDADES (Lo que faltaba seg�n tu Vista) ---
        public string TopicName { get; set; } // Para mostrar "Matem�ticas" en lugar de "1"
        public double Progress { get; set; }  // Para mostrar el porcentaje (ej. 50, 100)

        private readonly CConect _db;

        public CLessons()
        {
            _db = new CConect();
        }

        // Constructor actualizado
        public CLessons(int idLesson, int idTopic, string title, int grade, bool state, string topicName, double progress)
        {
            IdLesson = idLesson;
            IdTopic = idTopic;
            Title = title;
            Grade = grade;
            State = state;
            TopicName = topicName;
            Progress = progress;
            _db = new CConect();
        }

        // NOTA: Agregu� 'customerId' como par�metro. Es necesario para saber DE QUI�N calcular el progreso.
        public List<CLessons> GetLessonsByGrade(string targetGradeText, int customerId, out string errorMessage)
        {
            errorMessage = string.Empty;
            List<CLessons> lessons = new List<CLessons>();

            int gradeNumber = ExtraerNumeroDeGrado(targetGradeText);

            NpgsqlConnection connection = null;

            try
            {
                connection = _db.EstablecerConexion();
                if (connection == null)
                {
                    errorMessage = "No se pudo conectar a la base de datos.";
                    return lessons;
                }

                // --- SQL ACTUALIZADO ---
                // Hacemos JOIN con 'topic' para sacar el nombre.
                // Hacemos LEFT JOIN con 'answer' (filtrando por el usuario) para calcular el promedio.
                string sql = @"
                    SELECT 
                        l.id_lesson, 
                        l.id_topic, 
                        l.title, 
                        l.grade, 
                        l.state,
                        t.topic_name,
                        COALESCE(ROUND(AVG(a.score)), 0) as progress
                    FROM lesson l
                    JOIN topic t ON l.id_topic = t.id_topic
                    LEFT JOIN exercise e ON l.id_lesson = e.id_lesson
                    LEFT JOIN answer a ON e.id_exercise = a.id_exercise AND a.id_customer = @customerId
                    WHERE l.grade = @grade AND l.state = TRUE
                    GROUP BY l.id_lesson, l.id_topic, l.title, l.grade, l.state, t.topic_name
                    ORDER BY l.id_lesson";

                using (var cmd = new NpgsqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@grade", gradeNumber);
                    cmd.Parameters.AddWithValue("@customerId", customerId); // Pasamos el ID del usuario

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lessons.Add(new CLessons(
                                idLesson: reader.GetInt32(reader.GetOrdinal("id_lesson")),
                                idTopic: reader.GetInt32(reader.GetOrdinal("id_topic")),
                                title: reader.GetString(reader.GetOrdinal("title")),
                                grade: reader.GetInt32(reader.GetOrdinal("grade")),
                                state: reader.GetBoolean(reader.GetOrdinal("state")),
                                // Mapeamos las nuevas columnas
                                topicName: reader.GetString(reader.GetOrdinal("topic_name")),
                                progress: Convert.ToDouble(reader.GetValue(reader.GetOrdinal("progress")))
                            ));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = "Error al obtener las lecciones: " + ex.Message;
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                    connection.Close();
            }

            return lessons;
        }

        private int ExtraerNumeroDeGrado(string gradoTexto)
        {
            if (string.IsNullOrWhiteSpace(gradoTexto)) return 0;
            foreach (char c in gradoTexto)
            {
                if (char.IsDigit(c)) return int.Parse(c.ToString());
            }
            return 0;
        }
    }
}
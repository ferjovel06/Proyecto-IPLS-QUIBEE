﻿using System;
using Npgsql;
using System.Data; 

namespace QUIBEE_IPLS.Class
{

    public class CRegister
    {
        public bool RegisterUser(string nickname, string grade, string gender, string role, string password, out string errorMessage)
        {
            errorMessage = "";
            NpgsqlConnection conn = null;

            if (string.IsNullOrWhiteSpace(nickname) || string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "El Nickname y la Contraseña son campos obligatorios.";
                return false;
            }

            try
            {
                CConect conexion = new CConect();
                conn = conexion.EstablecerConexion();

                if (conn == null)
                {
                    errorMessage = "Error de conexión a la base de datos. Verifique App.config.";
                    return false;
                }
                string checkQuery = "SELECT COUNT(*) FROM customer WHERE nickname = @nickname";
                using (var checkCmd = new NpgsqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@nickname", nickname);
                    long existingUsers = (long)checkCmd.ExecuteScalar();

                    if (existingUsers > 0)
                    {
                        errorMessage = "Error de Registro: El Nickname ya existe. Por favor, elige otro.";
                        return false;
                    }
                }

                string insertQuery = @"INSERT INTO customer (nickname, password, grade, gender, role)
                                     VALUES (@nickname, @password, @grade, @gender, @role)";

                using (var cmd = new NpgsqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@nickname", nickname);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@grade", grade);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@role", role);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return true;
                    }
                    else
                    {
                        errorMessage = "Error: La inserción en la base de datos no afectó ninguna fila.";
                        return false;
                    }
                }
            }
            catch (NpgsqlException sqlEx)
            {
                errorMessage = $"Error de Base de Datos: {sqlEx.Message}";
                System.Windows.MessageBox.Show(errorMessage, "Error DB", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                return false;
            }
            catch (Exception ex)
            {
                errorMessage = "Error general al registrar el usuario: " + ex.Message;
                System.Windows.MessageBox.Show(errorMessage, "Error General", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                return false;
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
    }
}
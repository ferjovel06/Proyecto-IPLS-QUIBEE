﻿using Npgsql;

namespace QUIBEE_IPLS.Class
{
    internal class CConect
    {
            private static readonly string servidor = "aws-1-us-east-1.pooler.supabase.com";
            private static readonly string BaseDeDatos = "postgres";
            private static readonly string usuario = "postgres.kbnawicyaqghvwwurqig";
            private static readonly string password = "AsceAWKbtmRgJjN0";
            private static readonly string puerto = "5432";

            private readonly string cadenaConexion =
                $"Server={servidor};Port={puerto};User Id={usuario};Password={password};Database={BaseDeDatos};";

            public NpgsqlConnection EstablecerConexion()
            {
                var conn = new NpgsqlConnection(cadenaConexion);
                conn.Open();
                return conn;
            }
    }
}
